// src/features/schemes/scheme.routes.js
const { Router } = require('express');
const { authenticate } = require('../../middleware/auth.middleware');
const { authorize } = require('../../middleware/rbac.middleware');
const {
  createSchemeHandler,
  getSchemesHandler,
  updateSchemeHandler,
  deleteSchemeHandler
} = require('./scheme.controller');

const router = Router();

// Admin-only routes for managing schemes
router.post('/', authenticate, authorize(['ADMIN']), createSchemeHandler); // Create
router.get('/', authenticate, authorize(['ADMIN', 'INSTITUTE', 'MEMBER']), getSchemesHandler); // Read
router.put('/:id', authenticate, authorize(['ADMIN']), updateSchemeHandler); // Update
router.delete('/:id', authenticate, authorize(['ADMIN']), deleteSchemeHandler); // Delete

module.exports = router;