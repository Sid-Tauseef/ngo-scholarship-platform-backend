// src/features/schemes/scheme.controller.js
const { createScheme, getAllSchemes, updateScheme, deleteScheme } = require('./scheme.service');

async function createSchemeHandler(req, res, next) {
  try {
    const scheme = await createScheme(req.body);
    res.status(201).json({ success: true, data: scheme });
  } catch (err) {
    next(err);
  }
}

async function getSchemesHandler(req, res, next) {
  try {
    const schemes = await getAllSchemes();
    res.json({ success: true, data: schemes });
  } catch (err) {
    next(err);
  }
}

async function updateSchemeHandler(req, res, next) {
  try {
    const { id } = req.params;
    const updated = await updateScheme(id, req.body);
    if (!updated) return res.status(404).json({ success: false, message: 'Scheme not found' });
    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
}

async function deleteSchemeHandler(req, res, next) {
  try {
    const { id } = req.params;
    await deleteScheme(id);
    res.json({ success: true, message: 'Scheme deleted' });
  } catch (err) {
    next(err);
  }
}

module.exports = { createSchemeHandler, getSchemesHandler, updateSchemeHandler, deleteSchemeHandler };